# Alamin Marketplace BD

আধুনিক বাংলা ই-কমার্স প্ল্যাটফর্ম - আল-আমিন মার্কেটপ্লেস (Alamin Marketplace BD)।

## 🚀 বৈশিষ্ট্যসমূহ
- সম্পূর্ণ বাংলা ইন্টারফেস
- Firebase Realtime Database লাইভ ডাটাবেজ সংযোগ
- Firebase Authentication (ইমেইল/পাসওয়ার্ড ও অতিথি মোড)
- লাইভ ব্যানার স্লাইডার (অটো-স্ক্রোল, সোয়াইপ ও ডট ইন্ডিকেটর)
- লাইভ লোগো সাপোর্ট
- ক্যাটাগরি ভিত্তিক পণ্য ফিল্টারিং ও রিয়েলটাইম সার্চ
- পণ্যের বিস্তারিত তথ্য ও বিশেষ শর্তাবলী বক্স
- কার্ট ও ক্যাশ অন ডেলিভারি (COD) চেকআউট
- অর্ডারের লাইভ ট্র্যাকিং ও বিস্তারিত তালিকা
- সম্পূর্ণ রেসপনসিভ (মোবাইল ও ডেস্কটপ ফ্রেন্ডলি)

## 🛠️ প্রযুক্তি (Tech Stack)
- **Frontend Framework:** React 19 + TypeScript
- **Bundler:** Vite
- **Styling:** Tailwind CSS
- **Database & Auth:** Firebase (Realtime Database & Authentication)
- **Icons:** Lucide React

## 📦 লোকাল ডেভেলপমেন্ট সেটআপ (Local Setup)

১. ডিপেন্ডেন্সি ইনস্টল করুন:
```bash
npm install
```

২. ডেভেলপমেন্ট সার্ভার চালু করুন:
```bash
npm run dev
```
এরপর ব্রাউজারে `http://localhost:3000` ওপেন করুন।

## 🌐 প্রোডাকশন বিল্ড (Production Build)
```bash
npm run build
```
এটি `dist/` ফোল্ডারে অপ্টিমাইজড প্রোডাকশন ফাইল তৈরি করবে।

## 🔥 Firebase Hosting-এ ডেপ্লয়মেন্ট
```bash
npm run build
firebase deploy --only hosting
```

## ☁️ Vercel / Netlify ডেপ্লয়মেন্ট
GitHub-এ এই রিপোজিটরিটি পুশ করার পর Vercel বা Netlify-তে ইম্পোর্ট করে নিন:
- **Build Command:** `npm run build`
- **Output Directory:** `dist`
